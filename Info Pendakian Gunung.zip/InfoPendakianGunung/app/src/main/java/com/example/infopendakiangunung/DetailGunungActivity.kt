package com.example.infopendakiangunung

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.util.Log
import com.bumptech.glide.Glide
import com.example.infopendakiangunung.databinding.ActivityDetailGunungBinding
import com.example.infopendakiangunung.model.ModelGunung
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class DetailGunungActivity : AppCompatActivity(), OnMapReadyCallback {
    var lat: Double = 0.0
    var lng: Double = 0.0
    var namaGunung: String? = null
    private lateinit var binding: ActivityDetailGunungBinding
    private lateinit var mMap: GoogleMap
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailGunungBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val gunungnya = intent.getParcelableExtra<ModelGunung>("DETAIL_GUNUNG")
        val mapFragment = supportFragmentManager.findFragmentById(R.id.fMap) as SupportMapFragment
        if (gunungnya != null) {
            Glide.with(this)
                .load(gunungnya.image_gunung)
                .into(binding.ivGunung)
            binding.tvNamaGunung.text = gunungnya.nama
            binding.tvLokasiGunung.text = gunungnya.lokasi
            binding.tvDeskripsi.text = justifyText(gunungnya.deskripsi)
            binding.tvDaftarJalur.text = gunungnya.jalur_pendakian
            binding.tvInformasinya.text = gunungnya.info_gunung
            lat = gunungnya.lat!!
            lng = gunungnya.lon!!
            namaGunung = gunungnya.nama
        }
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(p0: GoogleMap) {
        mMap = p0
        val latLng = LatLng(lat, lng)
        mMap.addMarker(MarkerOptions().position(latLng).title(namaGunung))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16f))
    }

    fun justifyText(text: String?): Spanned {
        return Html.fromHtml("<p align=\"justify\">$text</p>", Html.FROM_HTML_MODE_LEGACY)
    }
}