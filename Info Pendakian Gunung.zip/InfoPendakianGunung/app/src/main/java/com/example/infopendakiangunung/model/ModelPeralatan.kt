package com.example.infopendakiangunung.model

class ModelPeralatan (
    var nama: String? = null,
    var image_url: String? = null,
    var tipe: String? = null,
    var deskripsi: String? = null,
    var tips: String? = null
)