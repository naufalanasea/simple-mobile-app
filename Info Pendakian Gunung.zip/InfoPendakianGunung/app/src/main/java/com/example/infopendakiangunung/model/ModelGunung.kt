package com.example.infopendakiangunung.model

import android.os.Parcel
import android.os.Parcelable

class ModelGunung (
    val deskripsi: String? = null,
    val image_gunung: String? = null,
    val info_gunung: String? = null,
    val jalur_pendakian: String? = null,
    val lat: Double? = null,
    val lokasi: String? = null,
    val lon: Double? = null,
    val nama: String? = null
): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Double::class.java.classLoader) as? Double,
        parcel.readString(),
        parcel.readValue(Double::class.java.classLoader) as? Double,
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(deskripsi)
        parcel.writeString(image_gunung)
        parcel.writeString(info_gunung)
        parcel.writeString(jalur_pendakian)
        parcel.writeValue(lat)
        parcel.writeString(lokasi)
        parcel.writeValue(lon)
        parcel.writeString(nama)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ModelGunung> {
        override fun createFromParcel(parcel: Parcel): ModelGunung {
            return ModelGunung(parcel)
        }

        override fun newArray(size: Int): Array<ModelGunung?> {
            return arrayOfNulls(size)
        }
    }
}
