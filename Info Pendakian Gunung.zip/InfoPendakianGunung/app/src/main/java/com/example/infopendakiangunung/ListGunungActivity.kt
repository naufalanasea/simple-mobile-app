package com.example.infopendakiangunung

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import com.example.infopendakiangunung.adapter.AdapterListGunung
import com.example.infopendakiangunung.adapter.AdapterLokasiGunung
import com.example.infopendakiangunung.databinding.ActivityListGunungBinding
import com.example.infopendakiangunung.model.ModelGunung
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ListGunungActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListGunungBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListGunungBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val lokasi = intent.getStringExtra("LOKASI")
        val username = intent.getStringExtra("USERNAME_KEY")

        binding.rvLokasiGunung.layoutManager = GridLayoutManager(this, 2)
        binding.rvLokasiGunung.setHasFixedSize(true)
        binding.tvLokasiGunung.text = lokasi

        binding.apply {
            ibBack.setOnClickListener {
                startActivity(Intent(this@ListGunungActivity, MainActivity::class.java).putExtra("USERNAME_KEY", username))
                finish()
            }
        }

        if (lokasi != null) {
            getMountDataFromFirebase(lokasi)
        }
    }

    private fun getMountDataFromFirebase(lokasi: String) {
        // Referensi ke Firebase Database
        val database = FirebaseDatabase
            .getInstance("https://project1-dd2a7-default-rtdb.firebaseio.com/")
            .reference
            .child("gunung")

        // Ambil data dari Firebase
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val dataList = mutableListOf<ModelGunung>()
                for (i in snapshot.children) {
                    val data = i.value as Map<*, *>
                    data.let {
                        if (data["lokasi"] == lokasi) {
                            val gunung = it["nama_gunung"] as ArrayList<*>
                            for (j in 0 until gunung.size) {
                                val deskripsi = (gunung[j] as Map<*, *>)["deskripsi"] as String
                                val image = (gunung[j] as Map<*, *>)["image_gunung"] as String
                                val info = (gunung[j] as Map<*, *>)["info_gunung"] as String
                                val jalur = (gunung[j] as Map<*, *>)["jalur_pendakian"] as String
                                val lat = (gunung[j] as Map<*, *>)["lat"] as Double
                                val lokasi = (gunung[j] as Map<*, *>)["lokasi"] as String
                                val lon = (gunung[j] as Map<*, *>)["lon"] as Double
                                val nama = (gunung[j] as Map<*, *>)["nama"] as String
                                dataList.add(ModelGunung(deskripsi, image, info, jalur, lat, lokasi, lon, nama))
                            }
                        }
                    }
                }
                binding.rvLokasiGunung.adapter = AdapterListGunung(this@ListGunungActivity, dataList)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DATABASE ERROR", error.toString())
            }

        })
    }
}