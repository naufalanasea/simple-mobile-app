package com.example.infopendakiangunung

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.infopendakiangunung.adapter.AdapterLokasiGunung
import com.example.infopendakiangunung.adapter.AdapterPeralatan
import com.example.infopendakiangunung.databinding.ActivityPeralatanBinding
import com.example.infopendakiangunung.model.ModelGunung
import com.example.infopendakiangunung.model.ModelPeralatan
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class PeralatanActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPeralatanBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPeralatanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra("USERNAME_KEY")
        binding.rvPeralatanGunung.layoutManager = LinearLayoutManager(this)
        binding.rvPeralatanGunung.setHasFixedSize(true)

        binding.apply {
            ibBack.setOnClickListener {
                startActivity(Intent(this@PeralatanActivity, MainActivity::class.java).putExtra("USERNAME_KEY", username))
                finish()
            }
        }

        getToolsDataFromFirebase()
    }

    private fun getToolsDataFromFirebase() {
        // Referensi ke Firebase Database
        val database = FirebaseDatabase
            .getInstance("https://project1-dd2a7-default-rtdb.firebaseio.com/")
            .reference
            .child("peralatan")

        // Ambil data dari Firebase
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val dataList = mutableListOf<ModelPeralatan>()
                for (i in snapshot.children) {
                    val data = i.getValue(ModelPeralatan::class.java)
                    data?.let {
                        dataList.add(it)
                    }
                }
                binding.rvPeralatanGunung.adapter = AdapterPeralatan(this@PeralatanActivity, dataList)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DATABASE ERROR", error.toString())
            }

        })
    }
}