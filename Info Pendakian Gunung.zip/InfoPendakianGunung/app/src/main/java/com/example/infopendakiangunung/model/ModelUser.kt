package com.example.infopendakiangunung.model

class ModelUser (
    val username: String? = null,
    val password: String? = null
)