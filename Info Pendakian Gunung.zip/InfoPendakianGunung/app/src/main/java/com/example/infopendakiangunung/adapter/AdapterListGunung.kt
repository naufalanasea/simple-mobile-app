package com.example.infopendakiangunung.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.infopendakiangunung.DetailGunungActivity
import com.example.infopendakiangunung.databinding.ItemListGunungBinding
import com.example.infopendakiangunung.model.ModelGunung

class AdapterListGunung(private val ctx: Context, private val data: List<ModelGunung>): RecyclerView.Adapter<AdapterListGunung.ListGunungViewHolder>() {
    inner class ListGunungViewHolder(private val binding: ItemListGunungBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(gunung: ModelGunung) {
            binding.tvNamaGunung.text = gunung.nama
            binding.tvLokasiGunung.text = gunung.lokasi
            Glide.with(ctx)
                .load(gunung.image_gunung)
                .into(binding.ivGunung)

            binding.root.setOnClickListener {
                binding.root.context.startActivity(Intent(ctx, DetailGunungActivity::class.java).putExtra("DETAIL_GUNUNG", gunung))
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListGunungViewHolder = ListGunungViewHolder(ItemListGunungBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: ListGunungViewHolder, position: Int) {
        holder.bind(data[position])
    }
}