package com.example.infopendakiangunung.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.infopendakiangunung.databinding.ItemPeralatanBinding
import com.example.infopendakiangunung.model.ModelPeralatan

class AdapterPeralatan(private val ctx: Context, private val data: List<ModelPeralatan>): RecyclerView.Adapter<AdapterPeralatan.PeralatanViewHolder>() {
    inner class PeralatanViewHolder(private val binding: ItemPeralatanBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(alat: ModelPeralatan) {
            binding.tvNamaPeralatan.text = alat.nama
            binding.tvTipePeralatan.text = alat.tipe
            Glide.with(ctx)
                .load(alat.image_url)
                .into(binding.ivPeralatan)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PeralatanViewHolder = PeralatanViewHolder(ItemPeralatanBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: PeralatanViewHolder, position: Int) {
        holder.bind(data[position])
    }
}