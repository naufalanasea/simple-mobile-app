package com.example.infopendakiangunung.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.infopendakiangunung.ListGunungActivity
import com.example.infopendakiangunung.R
import com.example.infopendakiangunung.databinding.ItemLokasiGunungBinding
import com.example.infopendakiangunung.model.ModelGunung

class AdapterLokasiGunung(private val data: List<String>): RecyclerView.Adapter<AdapterLokasiGunung.LokasiGunungViewHolder>() {
    class LokasiGunungViewHolder(private val binding: ItemLokasiGunungBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(lokasi: String) {
            binding.tvLokasiGunung.text = lokasi
            when (lokasi) {
                "Jawa Timur" -> binding.ivGunung.setImageResource(R.drawable.ic_jatim)
                "Jawa Tengah" -> binding.ivGunung.setImageResource(R.drawable.ic_jateng)
                "Jawa Barat" -> binding.ivGunung.setImageResource(R.drawable.ic_jabar)
                "Luar Pulau Jawa" -> binding.ivGunung.setImageResource(R.drawable.ic_luar_jawa)
            }
            binding.root.setOnClickListener {
                binding.root.context.startActivity(Intent(binding.root.context, ListGunungActivity::class.java).putExtra("LOKASI", lokasi))
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LokasiGunungViewHolder = LokasiGunungViewHolder(ItemLokasiGunungBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: LokasiGunungViewHolder, position: Int) {
        holder.bind(data[position])
    }
}