package com.example.infopendakiangunung

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.infopendakiangunung.adapter.AdapterLokasiGunung
import com.example.infopendakiangunung.databinding.ActivityMainBinding
import com.example.infopendakiangunung.model.ModelGunung
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra("USERNAME_KEY")
        binding.rvLokasiGunung.layoutManager = LinearLayoutManager(this)
        binding.rvLokasiGunung.setHasFixedSize(true)
        binding.tvUsername.text = username

        getMountDataFromFirebase()

        binding.apply {
            fabPeralatan.setOnClickListener {
                startActivity(Intent(this@MainActivity, PeralatanActivity::class.java).putExtra("USERNAME_KEY", username))
            }
        }
    }

    private fun getMountDataFromFirebase() {
        // Referensi ke Firebase Database
        val database = FirebaseDatabase
            .getInstance("https://project1-dd2a7-default-rtdb.firebaseio.com/")
            .reference
            .child("gunung")

        // Ambil data dari Firebase
        database.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val dataList = mutableListOf<String>()
                for (i in snapshot.children) {
                    val data = i.value as Map<*, *>
                    data.let {
                        dataList.add(it["lokasi"].toString())
                    }
                }
                binding.rvLokasiGunung.adapter = AdapterLokasiGunung(dataList)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DATABASE ERROR", error.toString())
            }

        })
    }
}