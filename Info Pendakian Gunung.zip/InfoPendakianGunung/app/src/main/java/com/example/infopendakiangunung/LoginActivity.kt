package com.example.infopendakiangunung

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.infopendakiangunung.databinding.ActivityLoginBinding
import com.example.infopendakiangunung.model.ModelUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inisialisasi Firebase Database
        val database = FirebaseDatabase.getInstance("https://project1-dd2a7-default-rtdb.firebaseio.com/")
        val reference = database.getReference("users")

        binding.apply {
            // Ketika tombol Sign Up ditekan
            btnSignUp.setOnClickListener {
                registerUser(reference)
            }

            // Ketika tombol Log in ditekan
            btnLogin.setOnClickListener {
                loginUser(reference)
            }
        }
    }

    private fun loginUser(reference: DatabaseReference) {
        // Tangkap username dan password
        val username = binding.etUsername.text.toString()
        val password = binding.etPassword.text.toString()

        if (username != "" && password != "") {
            // Ambil referensi ke node username
            val userRef = reference.child(username)
            // Baca dan pengecekan data Login
            userRef.addListenerForSingleValueEvent(object : ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val data = snapshot.value as? Map<*, *>
                        data?.let {
                            if (it["password"] == password) {
                                // Login berhasil
                                Toast.makeText(this@LoginActivity, "Login Berhasil", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this@LoginActivity, MainActivity::class.java).putExtra("USERNAME_KEY", data["username"] as String))
                                finish()
                            } else {
                                // Login gagal
                                Toast.makeText(this@LoginActivity, "Password Salah", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        Toast.makeText(this@LoginActivity, "Email tidak ditemukan", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle onCancelled
                }

            })
        } else {
            Toast.makeText(this@LoginActivity, "Harap data diisi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun registerUser(reference: DatabaseReference) {
        // Tangkap username dan password
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        // Membuat objek user
        val user = ModelUser(username, password)

        // Ambil referensi ke node username
        val userRef = reference.child(username)
        // Pengecekan username
        userRef.addListenerForSingleValueEvent(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    // Email sudah ada
                    Toast.makeText(this@LoginActivity, "Email telah terdaftar", Toast.LENGTH_SHORT).show()
                } else {
                    userRef.setValue(user)
                        .addOnSuccessListener {
                            // Berhasil Sign Up
                            Toast.makeText(this@LoginActivity, "Sign Up Berhasil", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener {
                            // Gagal Sign Up
                            Toast.makeText(this@LoginActivity, "Gagal Sign Up", Toast.LENGTH_SHORT).show()
                        }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled
            }

        })
    }
}